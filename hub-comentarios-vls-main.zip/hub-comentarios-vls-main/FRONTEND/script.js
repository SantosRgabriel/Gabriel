import { CommentComponent } from "./Comment/CommentComponent.js";

CommentComponent.run();